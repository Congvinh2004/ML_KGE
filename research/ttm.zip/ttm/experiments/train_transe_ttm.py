"""
Train TransE with Triple Trustiness Model (TransT)

Based on: Zhao et al., "Embedding Learning with Triple Trustiness on Noisy Knowledge Graph", 2019

Script này train TransT model trên WN18RR hoặc FB15K237
"""

import sys
import os

# Add paths
sys.path.insert(0, '.')
sys.path.insert(0, 'research')

import torch
from openke.config import Trainer, Tester
from openke.data import TestDataLoader
from openke.data.PyTorchTrainDataLoader import PyTorchTrainDataLoader

# Import TTM components từ thư mục ttm
from research.ttm import TransE_TTM, TrustinessCalculator, TTM_Loss, TTM_NegativeSampling

# ============================================
# Configuration
# ============================================
DATASET_PATH = "./benchmarks/WN18RR/"  # Hoặc "./benchmarks/FB15K237/"
CHECKPOINT_PATH = "./research/ttm/checkpoints"
os.makedirs(CHECKPOINT_PATH, exist_ok=True)

# TransT Configuration
TRANST_CONFIG = {
    'dim': 100,              # Embedding dimension
    'margin': 6.0,           # Margin for loss
    'train_times': 2000,     # Number of epochs
    'alpha': 0.1,            # Learning rate
    'nbatches': 50,          # Number of batches per epoch
    'neg_ent': 5,            # Negative samples per positive
    'threads': 4,            # Number of threads
    'p_norm': 1,             # L1 distance
    'norm_flag': True,       # Normalize embeddings
    'type_constrain': False, # Use type constraint in evaluation
    
    # TTM specific
    'use_trustiness': True,  # Có dùng trustiness không
    'alpha_trust': 0.5,      # Weight cho type-based trustiness
    'beta_trust': 0.5,       # Weight cho description-based trustiness
    'use_cross_entropy': True,  # Dùng cross-entropy loss (True) hay margin loss (False)
}

print("="*60)
print("⚙️  TransT (TransE + Triple Trustiness) Configuration")
print("="*60)
for key, value in TRANST_CONFIG.items():
    print(f"   {key}: {value}")

# ============================================
# Step 1: Load Data
# ============================================
print("\n📂 Loading data...")
train_dataloader = PyTorchTrainDataLoader(
    in_path=DATASET_PATH,
    nbatches=TRANST_CONFIG['nbatches'],
    threads=TRANST_CONFIG['threads'],
    sampling_mode="normal",
    bern_flag=1,
    filter_flag=1,
    neg_ent=TRANST_CONFIG['neg_ent'],
    neg_rel=0
)

print(f"✅ Data loaded: {train_dataloader.get_ent_tot()} entities, {train_dataloader.get_rel_tot()} relations")

test_dataloader = TestDataLoader(DATASET_PATH, "link")
print("✅ Test dataloader ready!")

# ============================================
# Step 2: Calculate Trustiness (nếu cần)
# ============================================
trustiness_calculator = None
trustiness_weights = None

if TRANST_CONFIG['use_trustiness']:
    print("\n📊 Calculating trustiness scores...")
    
    trustiness_calculator = TrustinessCalculator(
        dataset_path=DATASET_PATH,
        alpha=TRANST_CONFIG['alpha_trust'],
        beta=TRANST_CONFIG['beta_trust']
    )
    
    # Load entity types và descriptions
    trustiness_calculator.load_entity_types()
    trustiness_calculator.load_entity_descriptions()
    
    # Tính trustiness cho training triples
    # (Có thể pre-calculate và lưu vào file)
    print("✅ Trustiness calculator ready!")
    
    # Lấy trustiness weights (có thể load từ file hoặc calculate on-the-fly)
    trustiness_weights = trustiness_calculator.trustiness_scores
    print(f"   Loaded {len(trustiness_weights)} trustiness scores")
else:
    print("\n⚠️  Trustiness disabled, using standard TransE")

# ============================================
# Step 3: Create TransT Model
# ============================================
print("\n🏗️  Creating TransT model...")
transt = TransE_TTM(
    ent_tot=train_dataloader.get_ent_tot(),
    rel_tot=train_dataloader.get_rel_tot(),
    dim=TRANST_CONFIG['dim'],
    p_norm=TRANST_CONFIG['p_norm'],
    norm_flag=TRANST_CONFIG['norm_flag'],
    margin=TRANST_CONFIG['margin'],
    trustiness_calculator=trustiness_calculator
)

print("✅ TransT model created!")

# ============================================
# Step 4: Create TTM Loss
# ============================================
print("\n📊 Creating TTM loss function...")
ttm_loss = TTM_Loss(
    margin=TRANST_CONFIG['margin'],
    use_cross_entropy=TRANST_CONFIG['use_cross_entropy'],
    trustiness_weights=trustiness_weights
)

print("✅ TTM loss function created!")

# ============================================
# Step 5: Create Strategy
# ============================================
print("\n🔄 Creating TTM strategy...")
model = TTM_NegativeSampling(
    model=transt,
    loss=ttm_loss,
    batch_size=train_dataloader.get_batch_size()
)

print("✅ TTM strategy created!")

# ============================================
# Step 6: Train Model
# ============================================
print("\n🚀 Starting training...")
print("="*60)

trainer = Trainer(
    model=model,
    data_loader=train_dataloader,
    train_times=TRANST_CONFIG['train_times'],
    alpha=TRANST_CONFIG['alpha'],
    use_gpu=True
)

trainer.run()

# Save checkpoint
checkpoint_path = f'{CHECKPOINT_PATH}/transt_wn18rr.ckpt'
transt.save_checkpoint(checkpoint_path)
print("="*60)
print("✅ Training complete!")
print(f"✅ Checkpoint saved: {checkpoint_path}")

# ============================================
# Step 7: Test Model
# ============================================
print("\n🧪 Testing model...")
print("="*60)

transt.load_checkpoint(checkpoint_path)
tester = Tester(model=transt, data_loader=test_dataloader, use_gpu=True)

mrr, mr, hit10, hit3, hit1 = tester.run_link_prediction(
    type_constrain=TRANST_CONFIG['type_constrain']
)

print("="*60)
print("📊 TransT RESULTS:")
print("="*60)
print(f"MRR: {mrr:.4f}  MR: {mr:.1f}  Hits@10: {hit10:.4f}  Hits@3: {hit3:.4f}  Hits@1: {hit1:.4f}")
print("="*60)

