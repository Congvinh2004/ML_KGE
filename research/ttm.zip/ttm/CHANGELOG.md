# 📝 Changelog - TTM Module

## Version 1.0.0 - 2024

### ✅ Đã tổ chức lại cấu trúc thư mục

**Trước đây:**
```
research/
├── models/
│   ├── TransE_TTM.py
│   ├── TrustinessCalculator.py
│   └── TTM_Loss.py
├── strategy/
│   └── TTM_NegativeSampling.py
└── experiments/
    └── train_transe_ttm.py
```

**Hiện tại:**
```
research/
└── ttm/                          # ⭐ Thư mục riêng
    ├── models/
    │   ├── TransE_TTM.py
    │   └── TrustinessCalculator.py
    ├── loss/
    │   └── TTM_Loss.py
    ├── strategy/
    │   └── TTM_NegativeSampling.py
    └── experiments/
        └── train_transe_ttm.py
```

### 🔄 Thay đổi

1. **Tạo thư mục `research/ttm/`** - Tổ chức tất cả TTM components
2. **Di chuyển files** - Tất cả TTM files vào `research/ttm/`
3. **Xóa files cũ** - Đã xóa các file duplicate trong `research/models/` và `research/strategy/`
4. **Cập nhật imports** - Sử dụng `from research.ttm import ...`

### 📦 Files đã xóa

- ❌ `research/models/TransE_TTM.py` → ✅ `research/ttm/models/TransE_TTM.py`
- ❌ `research/models/TrustinessCalculator.py` → ✅ `research/ttm/models/TrustinessCalculator.py`
- ❌ `research/models/TTM_Loss.py` → ✅ `research/ttm/loss/TTM_Loss.py`
- ❌ `research/strategy/TTM_NegativeSampling.py` → ✅ `research/ttm/strategy/TTM_NegativeSampling.py`
- ❌ `research/experiments/train_transe_ttm.py` → ✅ `research/ttm/experiments/train_transe_ttm.py`

### 📝 Cách sử dụng mới

**Trước:**
```python
from research.models.TransE_TTM import TransE_TTM
from research.models.TTM_Loss import TTM_Loss
from research.strategy.TTM_NegativeSampling import TTM_NegativeSampling
```

**Hiện tại:**
```python
from research.ttm import TransE_TTM, TTM_Loss, TTM_NegativeSampling
```

### ✨ Lợi ích

1. ✅ **Tổ chức rõ ràng** - Tất cả TTM ở một nơi
2. ✅ **Dễ import** - Import từ một module duy nhất
3. ✅ **Dễ bảo trì** - Tách biệt với code khác
4. ✅ **Có documentation** - README.md trong thư mục ttm

---

**Last Updated:** 2024

